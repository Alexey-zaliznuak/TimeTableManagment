from django.apps import AppConfig


class TimetablesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'timetables'
