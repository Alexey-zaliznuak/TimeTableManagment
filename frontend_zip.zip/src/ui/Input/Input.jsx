import React, { useState, useEffect, useRef } from 'react'
import styled from 'styled-components'
import { useForm, FormProvider, useFormContext } from "react-hook-form";
import { COLORS } from '../../consts/style';

import validateWorkers from '../../helpers/validateWork'

export const Input = ({ Dvalue, errors, name, validate, ...props }) => {
  const [value, setValue] = useState( Dvalue ? Dvalue : '')
  const [toggle, setToggle] = useState(false)
  const [haveValue, setHaveValue]  = useState(props.type === 'date' | props.type === 'time' ? true : false)
  const isSelect = props.type === 'select'

  let InputInForm = InputForm
  if(props.type === 'textarea') {
    InputInForm = IextAreaForm
  }
  const onChange = (object) => {
    setValue(object.value)
  }
  useEffect(() => {
    if(props.type != 'date' & props.type != 'time') { 
      setHaveValue(Boolean(value))
    }
  }, [ value ])



  const setSelectValue = (e) => {
    const Tvalue = e.target.getAttribute('value')
    setValue(Tvalue)
  }

  const { register } = useFormContext(); 

  return(<>
    <InputBox>
      <InputInForm
        onChange={ (e) => {setValue(e.target.value)} }
        value={value}
        {...register(name, {
          ...validateWorkers[validate],
          onChange: (e) => { onChange(e.target) }
        })}
        onFocus = {() => setToggle(true)}
        onBlur = {() => setToggle(false)}

        autocomplete={isSelect ? 'off' : 'on'}
        {...props} 
      />
      { props?.placeholder && <PlaceholderMod focusVisible={haveValue}>{props.placeholder}</PlaceholderMod>}
      { isSelect && (
        <SelectMenu toggle={toggle}>
          <SelectItem onClick={setSelectValue} value="1">1</SelectItem>
          <SelectItem onClick={setSelectValue} value="2">2</SelectItem>
        </SelectMenu>
      ) }


    </InputBox>
    { errors?.[name] && <ErrorInput name="placeholder">{errors?.[name].message}</ErrorInput>}
  </>)
}

const PlaceholderMod = styled.div`
  transition: all .3s linear;
  max-width: ${props => props.focusVisible ? "200px": "0"};
  white-space: nowrap;
  overflow: hidden;
  position: absolute;
  font-size: 13px;
  padding: 0  ${props => props.focusVisible ? "4px": "0"};
  color: white;
  background-color: #4990CD;
  border-radius: 3px;
  z-index: 1;
  top: -12px;
  left: 5px;

`
const ErrorInput = styled.span`
  font-size: 16px;
  margin: -10px 0 -5px 10px;
  color: red;
  
`
const InputBox = styled.div`
  position: relative;
  margin-top: 0px;
`
const SelectMenu = styled.div`
  width: 250px;
  border-radius: 5px;
  height: max-content;
  max-height: ${props => props.toggle ? '160px' : 0};
  overflow: hidden;
  background-color: #4990CD;
  transition: all .1s linear;
`
const SelectItem = styled.div`
  width: 100%;
  height: 32px;
  margin: 1px 0;
  background-color: ${COLORS.blue300};
`
const ClassFromInputs = `
  width:100%;
  background-color: #4990CD;
  cursor: pointer;
  display: block;
  padding: 20px;
  padding-bottom: 3px;
  padding-top: 3px;
  border-radius: 5px;
  border-width: 0px;
  color: white;
  & > *: {
    color: white;
  }
  font-size: 1.08em;
  
  border: 2px solid #4990CD;
  transition: all .1s linear;

  &::-webkit-input-placeholder {
    color: white;
  }
  &:hover {
    background-color: #4e7dc5;
    border-color: #4e7dc5;
  }
  &:focus {
    outline: none;
    padding-bottom: 8px;
    padding-top: 5px;
    background-color: #2f5b9d;
    border-color: #2f5b9d;
  }
`
const InputForm = styled.input` ${ClassFromInputs} `
const IextAreaForm = styled.textarea` 
  ${ClassFromInputs} 
  resize: vertical;
  min-height: 38px;
  max-height: 200px;

  transition: none;
  transition-property: border-color, background-color, padding-top, padding-bottom;
  transition-duration: .1s;
`