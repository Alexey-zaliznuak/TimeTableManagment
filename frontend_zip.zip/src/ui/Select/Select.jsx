import React, { useState, useEffect } from 'react'
import styled from 'styled-components'
import { useFormContext } from "react-hook-form"

import validateWorkers from '../../helpers/validateWork'

export const Select = ({ Dvalue, errors, name, validate, children, ...props }) => {
  const [value, setValue] = useState(Dvalue ? Dvalue : 0)
  const [haveValue, setHaveValue]  = useState(false)
  

  
  useEffect(() => {
    setHaveValue(Boolean(value))
  }, [ value ])

  const onChange = (object) => {
    setValue(object.value)
  }

  const { register } = useFormContext(); 

  return( <>
    <InputBox>
      <ClassFromInputs
        onChange={ (e) => {setValue(e.target.value)} }
        value={value}
        {...register(name, {
          ...validateWorkers[validate],
          onChange: (e) => { onChange(e.target) }
        })}
        {...props}
      >
          <option value="">{props.placeholder}</option>

        {props.options.map((option, i) => (
          <option key={i} value={option.value}>{option.label}</option>
        ))}
      </ClassFromInputs>
      { props?.placeholder && <PlaceholderMod myColor={props.myColor} focusVisible={haveValue}>{props.placeholder}</PlaceholderMod>}

    </InputBox>
    { errors?.[name] && <ErrorInput name="placeholder">{errors?.[name].message}</ErrorInput>}
  </>)
}

const PlaceholderMod = styled.div`
  transition: all .3s linear;
  max-width: ${props => props.focusVisible ? "200px": "0"};
  white-space: nowrap;
  overflow: hidden;
  position: absolute;
  font-size: 13px;
  padding: 0  ${props => props.focusVisible ? "4px": "0"};
  color: white;
  background-color: ${ props => props.myColor ? props.myColor : '#4990CD'};
  border-radius: 3px;
  z-index: 1;
  top: -12px;
  left: 5px;
`
const ErrorInput = styled.span`
  font-size: 16px;
  margin: -10px 0 -10px 10px
`
const InputBox = styled.div`
  position: relative;
  margin-top: 0px;
`
const ClassFromInputs = styled.select`
  width:100%;
  background-color: ${ props => props.myColor ? props.myColor : '#4990CD'};
  cursor: pointer;
  display: block;
  padding: 20px;
  padding-bottom: 3px;
  padding-top: 3px;
  border-radius: 5px;
  border-width: 0px;
  color: white;
  & > *: {
    color: white;
  }
  font-size: 1.08em;
  
  border: 2px solid ${ props => props.myColor ? props.myColor : '#4990CD'};
  transition: all .1s linear;

  &::-webkit-input-placeholder {
    color: white;
  }
  &:hover {
    background-color: ${ props => props.hoverColor ? props.hoverColor : '#4e7dc5'};
    border-color: ${ props => props.hoverColor ? props.hoverColor : '#4e7dc5'};
  }
  &:focus {
    outline: none;
    padding-bottom: 8px;
    padding-top: 5px;
    background-color: ${ props => props.focusColor ? props.focusColor : '#2f5b9d'};
    border-color: ${ props => props.focusColor ? props.focusColor : '#2f5b9d'};
  }
`