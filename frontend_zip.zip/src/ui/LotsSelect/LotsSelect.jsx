import React, { useState, useEffect } from 'react'
import styled from 'styled-components'
import { useFormContext } from "react-hook-form"

import { Button } from '../Button'
import validateWorkers from '../../helpers/validateWork'


export const LotsSelect = ({ value, errors, name, validate, children, ...props }) => {
  const [arr, setArr] = useState(value ? value : ['']);
  console.log(value)
 

  const onChange = (object, index) => {
    const temp = [...arr]
    temp[index] = object.value
    setArr(temp)
  }

  const { register, unregister } = useFormContext(); 

  const removeInput = (e) => {
    e.preventDefault()
    unregister(`${name}-${arr.length-1}`)
    setArr(s => {
      s.pop()
      return [
        ...s
      ]
    })
  }

  const addInput = (e) => {
    e.preventDefault()
    setArr(s => {
      return [
        ...s,
        ""
      ]
    })
  }

  return( <>
  {arr.map( (value, i) => (
    <>
      <InputBox>
        <InputForm
          value={value}
          {...register(`${name}-${i}`, {
            ...validateWorkers[validate],
            onChange: (e) => { onChange(e.target, i) }
          })}
          {...props}
        >
            <option value="">{props.placeholder}</option>

          {props.options.map((option, i) => (
            <option key={i} value={option.value}>{option.label}</option>
          ))}
        </InputForm>
        { props?.placeholder && <PlaceholderMod focusVisible={Boolean(arr[i])}>{props.placeholder}</PlaceholderMod>}

      </InputBox>
      { errors?.[`${name}-${i}`] && <ErrorInput name="placeholder">{errors?.[`${name}-${i}`].message}</ErrorInput>}
    </>
  ))}
  <ButtonGroup>
    <Button onClick={addInput} style={{ width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
      </svg>
    </Button>
    <Button onClick={removeInput} style={{ width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" class="bi bi-dash" viewBox="0 0 16 16">
        <path d="M4 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 4 8z"/>
      </svg>
    </Button>
  </ButtonGroup>
  </>)
}

const ButtonGroup = styled.div`
  display: flex;
  align-items: end;
  justify-content: end;
`
const PlaceholderMod = styled.div`
  transition: all .3s linear;
  max-width: ${props => props.focusVisible ? "200px": "0"};
  white-space: nowrap;
  overflow: hidden;
  position: absolute;
  font-size: 13px;
  padding: 0  ${props => props.focusVisible ? "4px": "0"};
  color: white;
  background-color: #4990CD;
  border-radius: 3px;
  z-index: 1;
  top: -12px;
  left: 5px;
`
const ErrorInput = styled.span`
  font-size: 16px;
  margin: -10px 0 -10px 10px
`
const InputBox = styled.div`
  position: relative;
  margin-top: 0px;
`
const ClassFromInputs = `
  width:100%;
  background-color: #4990CD;
  cursor: pointer;
  display: block;
  padding: 20px;
  padding-bottom: 3px;
  padding-top: 3px;
  border-radius: 5px;
  border-width: 0px;
  color: white;
  & > *: {
    color: white;
  }
  font-size: 1.08em;
  
  border: 2px solid #4990CD;
  transition: all .1s linear;

  &::-webkit-input-placeholder {
    color: white;
  }
  &:hover {
    background-color: #4e7dc5;
    border-color: #4e7dc5;
  }
  &:focus {
    outline: none;
    padding-bottom: 8px;
    padding-top: 5px;
    background-color: #2f5b9d;
    border-color: #2f5b9d;
  }
`
const InputForm = styled.select` ${ClassFromInputs} `