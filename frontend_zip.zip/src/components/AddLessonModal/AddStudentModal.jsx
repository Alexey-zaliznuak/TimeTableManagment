import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styled from "styled-components"
import { useForm, FormProvider, useFormContext } from "react-hook-form";
import { URL } from '../../consts/UserData';

import { Button, Input, Select, LotsSelect } from '../../ui';
import { FormWithValidate } from '../FormWithValidate/FormWithValidate';


export const AddStudentModal = ({show, handleClose, token, ...props}) => {
  const lotsKeys = ['work_days']


  const onSubmit = async data => {
    const submitData = { }

    for(const key in data) {
      const myKey = key.split('-')[0]
      console.log(key, data[key])
      
      if(lotsKeys.includes(myKey)){
        if(submitData[myKey]) {
          submitData[myKey].push(data[key])
        }else {
          submitData[myKey] = []
          submitData[myKey].push(data[key])
        }
      }else if(key == 'duration' | key == 'start_time'  ) {
        submitData[myKey] = data[key] + ':00'
     }
      else {
        submitData[myKey] = data[key]
      }
      
    }


    let options = {
      method: "POST",
      headers: new Headers({
          'Content-Type': 'application/json',
          'X-CSRFToken': token,
          Authorization:`Bearer ${token}`
      }),
      body: JSON.stringify(submitData)
    }
    console.log(submitData)
    await fetch(URL + 'students/', options)
    .then(data => {
      data.json()
        .then(json => {
          console.log(json)
          let alertt = ''
          for (const property in json) {
            alertt += `${property}: ${json[property]}\n`
          }
          if(data.status == 201) {
            alertt = 'Студент добавлен, пожалуйста, обновите страницу'
          }
          alert(alertt)
          if(data.status == 201) {
            handleClose()
          }
        })
    })

  }
  console.log(props)
  
  const GOptions = props.groups.map(group => ( 
    { value: group.id, label: group.name } 
  ))
  const UOptions = props.users.filter(x => x.role == "отсутствует").map(user => ( 
    { value: user.pk, label: user.username } 
  ))

  return <Modal
      show={show}
      onHide={handleClose}
      backdrop="static"
      keyboard={false}
    >
      <Modal.Header closeButton>
        <Modal.Title>Определение студента</Modal.Title>
      </Modal.Header>
      <Modal.Body>

      <FormWithValidate onSubmit={onSubmit}>
        <Select name='group' placeholder="Группу" validate="select" options={GOptions}/>
        <Select name='user' placeholder="Выберете пользователя" validate="select" options={UOptions}/>

        <RButton>Определение</RButton>
      </FormWithValidate>

        
      </Modal.Body>
      <Modal.Footer>
        <Button style={{ backgroundColor:"red" }} onClick={handleClose}>
          Отмена
        </Button>
      </Modal.Footer>
    </Modal>
}

const RButton = styled(Button)`
  width: 150px;
  margin-left: auto;
`


//  <form onSubmit={handleSubmit}>
//           <Form.Group className="mb-3">
//             <Form.Label>Класс</Form.Label>
//             <Form.Select >
//               <option >Выберете Группу</option>
//               <option value={'Disabled seleqct'} >Disabled seleqct</option>
//               <option value={'Disabled seleq13ct'} >Disabled seleq13ct</option>
//               <option value={'Disabled 123'} >Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Учитель</Form.Label>
//             <Form.Select >
//               <option>Disabled seleqct</option>
//               <option>Disabled seleq13ct</option>
//               <option>Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label  >Группы</Form.Label>
//             {
//               arr.map((item, i) => (
//                   <Form.Select
//                   name={i}
//                   key={i}
//                   onChange={handleChange}
//                   value={item.value ? item.value : 'Выберите группу'}
//                   type={item.type}
//                   >
//                     <option value={''} >Выберите группу</option>
//                     <option value={'Disabled seleqct'} >Disabled seleqct</option>
//                     <option value={'Disabled seleq13ct'} >Disabled seleq13ct</option>
//                     <option value={'Disabled 123'} >Disabled 123</option>
//                   </Form.Select>
//               ))
//             }
//           </Form.Group> 

//           <Button onClick={addInput} style={{marginLeft: 'auto', width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
//               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
//                 <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
//               </svg>
//             </Button>

//           <Form.Group className="mb-3">
//             <Form.Label>Урок</Form.Label>
//             <Form.Select >
//               <option>Disabled seleqct</option>
//               <option>Disabled seleq13ct</option>
//               <option>Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>День</Form.Label>
//             <Form.Control placeholder="Disabled input" type='date'/>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Начало Урока</Form.Label>
//             <Form.Control placeholder="Disabled input" type='time'/>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Продолжительность</Form.Label>
//             <Form.Control placeholder="Disabled input" type='time'/>
//           </Form.Group>
//           <Button type="submit">.</Button>
//         </form> 