import React, { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import styled from "styled-components"
import { useForm, FormProvider, useFormContext } from "react-hook-form";
import { URL } from '../../consts/UserData';

import { Button, Input, Select, LotsSelect } from '../../ui';
import { FormWithValidate } from '../FormWithValidate/FormWithValidate';

export const ULessonModal = ({lessonInModal, show, handleClose, token, ...props}) => {
  const lotsKeys = ['groups']
  console.log(lessonInModal)

  const onSubmit = async data => {
    const submitData = { }
    console.log(data)
    for(const key in data) {
      const myKey = key.split('-')[0]
      console.log(key, data[key])
      
      if(lotsKeys.includes(myKey)){
        if(submitData[myKey]) {
          submitData[myKey].push(data[key])
        }else {
          submitData[myKey] = []
          submitData[myKey].push(data[key])
        }
      }else if(key =='duration' |key == 'start_time'  ) {
        submitData[myKey] = data[key] + ':00'
     }
      else {
        submitData[myKey] = data[key]
      }
      
    }


    let options = {
      method: "PATCH",
      headers: new Headers({
          'Content-Type': 'application/json',
          'X-CSRFToken': token,
          Authorization:`Bearer ${token}`
      }),
      body: JSON.stringify(submitData)
    }
    console.log(submitData)
    console.log(URL + 'lessons/' + lessonInModal.id + '/')

    await fetch(URL + 'lessons/' + lessonInModal.id + '/', options)
    .then(data => {
      data.json()
        .then(json => {
          console.log(json)
          let alertt = ''
          for (const property in json) {
            alertt += `${property}: ${json[property]}\n`
          }
          if(data.status == 201) {
            alertt = 'Урок добавлен, пожалуйста, обновите страницу'
          }
          alert(alertt)
          if(data.status == 201) {
            handleClose()
          }
        })
    })

  }
  const TOptions = props.teachers.map(teach => (
    { value: teach.id, label: props.users.find(x => x.pk == teach.user).username }
  ))
  const CROptions = props.classRooms.map(teach => (
    { value: teach.id, label: teach.number }
  ))
  const TLOptions = props.typeLessons.map(teach => (
    { value: teach.id, label: teach.name }
  ))
  const GOptions = props.groups.map(group => ( 
    { value: group.id, label: group.name } 
  ))

  const DOptions = [
    { value: 1, label: 'Понедельник 1' },
    { value: 8, label: 'Понедельник 2' },
    { value: 2, label: 'Вторник 1' },
    { value: 9, label: 'Вторник 2' },
    { value: 3, label: 'Среда 1' },
    { value: 10, label: 'Среда 2' },
    { value: 4, label: 'Четверг 1' },
    { value: 11, label: 'Четверг 2' },
    { value: 5, label: 'Пятница 1' },
    { value: 12, label: 'Пятница 2' },
    { value: 6, label: 'Суббота 1' },
    { value: 13, label: 'Суббота 2' },
    { value: 7, label: 'Воскресение 1' },
    { value: 14, label: 'Воскресение 2' },
  ]
  const SBOptions = [
    { value: 0, label: 'Вся группа' },
    { value: 1, label: 'Подгруппа 1' },
    { value: 2, label: 'Подгруппа 2' },
  ]

  return <Modal
      show={show}
      onHide={handleClose}
      backdrop="static"
      keyboard={false}
    >
      <Modal.Header closeButton>
        <Modal.Title>Добавить урок</Modal.Title>
      </Modal.Header>
      <Modal.Body>

      <FormWithValidate onSubmit={onSubmit}>

          <Select Dvalue={lessonInModal.teacher} name="teacher" placeholder="Учитель" validate="select" options={TOptions}/>
          <Select Dvalue={lessonInModal.classroom} name="classroom" placeholder="Аудитория" validate="select" options={CROptions}/>
          <Select Dvalue={lessonInModal.lesson_type} name="lesson_type" placeholder="Урок" validate="select" options={TLOptions}/>
          <Input Dvalue={lessonInModal.start_time} name="start_time" type="time" placeholder="Начало" />
          <Input Dvalue={lessonInModal.duration} name="duration" type="time" placeholder="Продолжительность" />
          <Select Dvalue={lessonInModal.day} name="day" placeholder="День" validate="select" options={DOptions}/>
          <Select Dvalue={lessonInModal.subgroup} name="subgroup" placeholder="Подгруппа" options={SBOptions}/>
            
          <LotsSelect value={lessonInModal.groups} name='groups' placeholder="Выберете группу" validate="select" options={GOptions}/>

          <RButton>Регистрация</RButton>
        </FormWithValidate>

        
      </Modal.Body>
      <Modal.Footer>
        <Button style={{ backgroundColor:"red" }} onClick={handleClose}>
          Отмена
        </Button>
        <Button > Добавить </Button>
      </Modal.Footer>
    </Modal>
}

const RButton = styled(Button)`
  width: 150px;
  margin-left: auto;
`


//  <form onSubmit={handleSubmit}>
//           <Form.Group className="mb-3">
//             <Form.Label>Класс</Form.Label>
//             <Form.Select >
//               <option >Выберете Группу</option>
//               <option value={'Disabled seleqct'} >Disabled seleqct</option>
//               <option value={'Disabled seleq13ct'} >Disabled seleq13ct</option>
//               <option value={'Disabled 123'} >Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Учитель</Form.Label>
//             <Form.Select >
//               <option>Disabled seleqct</option>
//               <option>Disabled seleq13ct</option>
//               <option>Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label  >Группы</Form.Label>
//             {
//               arr.map((item, i) => (
//                   <Form.Select
//                   name={i}
//                   key={i}
//                   onChange={handleChange}
//                   value={item.value ? item.value : 'Выберите группу'}
//                   type={item.type}
//                   >
//                     <option value={''} >Выберите группу</option>
//                     <option value={'Disabled seleqct'} >Disabled seleqct</option>
//                     <option value={'Disabled seleq13ct'} >Disabled seleq13ct</option>
//                     <option value={'Disabled 123'} >Disabled 123</option>
//                   </Form.Select>
//               ))
//             }
//           </Form.Group> 

//           <Button onClick={addInput} style={{marginLeft: 'auto', width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
//               <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
//                 <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
//               </svg>
//             </Button>

//           <Form.Group className="mb-3">
//             <Form.Label>Урок</Form.Label>
//             <Form.Select >
//               <option>Disabled seleqct</option>
//               <option>Disabled seleq13ct</option>
//               <option>Disabled 123</option>
//             </Form.Select>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>День</Form.Label>
//             <Form.Control placeholder="Disabled input" type='date'/>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Начало Урока</Form.Label>
//             <Form.Control placeholder="Disabled input" type='time'/>
//           </Form.Group>
//           <Form.Group className="mb-3">
//             <Form.Label>Продолжительность</Form.Label>
//             <Form.Control placeholder="Disabled input" type='time'/>
//           </Form.Group>
//           <Button type="submit">.</Button>
//         </form> 