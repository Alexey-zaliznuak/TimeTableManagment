import React from "react";
import styled from 'styled-components'
import { useForm, FormProvider } from "react-hook-form"

const FormWithValidate = ({ defaultValues, children, onSubmit, ...props }) => {

  const methods = useForm({ defaultValues })
  const { handleSubmit, formState: { errors } } = methods

  return (
    <FormProvider {...methods} >
      <Form {...props} onSubmit={handleSubmit(onSubmit)}>
        {React.Children.map(children, child => {
          return child.props.name
            ? React.createElement(child.type, {
              ...{
                ...child.props,
                register: methods.register,
                key: child.props.name,
                errors: errors
              }
              })
            : child
        })}
      </Form>
    </FormProvider>
  )
}

export { FormWithValidate } 

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 15px;
`
