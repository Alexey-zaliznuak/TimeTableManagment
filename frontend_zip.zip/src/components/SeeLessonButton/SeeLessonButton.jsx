import { checkEqualDate, getFullDate, getFullTime } from "../../helpers/dateHalpers"
import styled from "styled-components"
import { Button } from "../../ui"


export const SeeLessonButton = ({ handleShow, lesson, groups, classRooms, typeLessons, settings = {}}) => {

    return <MyButton onClick={() => handleShow(lesson.id)}>
        <div style={{flex: 1}}>
            {settings.includes('group') ? lesson.groups.map(group => {
                return groups.find(x => x.id === group) ? groups.find(x => x.id === group).name : ''
            }).join(', ') + ' — '
            : " "} 
            { classRooms.find(x => x.id === lesson.classroom).number }{' | '}

            {  typeLessons.find(x => x.id === lesson.lesson_type).name }
        </div>
        
        {/* {settings.includes('time')  ? 
            <div>
                { getFullTime( new Date( lesson.start_time * 1000) ) }{' - '}
                { getFullTime( new Date( (lesson.start_time + lesson.duration) * 1000) ) }
            </div>  
        : ""} */}
        
    </MyButton>

}
const MyButton = styled(Button) `
  height: min-content;
  font-size: 14px;
  margin: 2px;
  display: flex;
  flex-direction: column;
`