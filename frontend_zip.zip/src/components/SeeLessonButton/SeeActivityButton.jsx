import { checkEqualDate, getFullDate, getFullTime } from "../../helpers/dateHalpers"
import styled from "styled-components"
import { Button } from "../../ui"
import { COLORS } from "../../consts/style"

export const SeeActivityButton = ({ handleShow, lesson, groups, classRooms, settings = {}}) => {
    console.log(lesson)
    return <MyButton onClick={() => handleShow(lesson.id)}>
        <div style={{flex: 1}}>
            {settings.includes('group') ? lesson.groups.map(group => {
                return groups.find(x => x.id === group) ? groups.find(x => x.id === group).name : ''
            }).join(', ') + ' — '
            : " "} 
            { classRooms.find(x => x.id === lesson.classroom).number }{' | '}
            { lesson.name }{' — '}

            {settings.includes('time')  ? 
                <>
                    { lesson.start_time }
                </>  
            : ""}
        </div>
        
        
    </MyButton>

}
const MyButton = styled(Button) `
  height: min-content;
  font-size: 14px;
  margin: 2px;
  display: flex;
  flex-direction: column;
  background-color: ${COLORS.green400};
  border-color: ${ COLORS.green400 };

  &:hover {
    color: rgb(220,220,220);
    background-color: ${COLORS.green500};
    border-color: ${COLORS.green500};
    box-shadow: 6px 3px 13px 4px rgba(117, 183, 152, 0.45);
  }
`