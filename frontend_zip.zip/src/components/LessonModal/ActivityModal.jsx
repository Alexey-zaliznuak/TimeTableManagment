import React from "react"
import Modal from 'react-bootstrap/Modal'

import { getFullTime } from "../../helpers/dateHalpers"
import { Button } from "../../ui"

export const ActivityModal = ({handleShowULesson, Admin, users, show, handleClose, typeLessons, teachers, classRooms, lessonInModal, groups}) => {
    
    
    if(Admin && show){
        console.log('Разрешаю удалять')
    }
    const DeleteLesson = async (id) => {
        let token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjgwNzg0NjgxLCJqdGkiOiJjYWFiYTc2YjhkYjY0MjQ2YjViYmZiODNmZDE3OGY0MCIsInVzZXJfaWQiOjJ9.rSydiyGy2vvtfDCoH0En0YlzPpPBnDPK2Fa2Y7kIKdg'
        const URLq = 'http://26.81.229.58:8000/api/v1/'
        const bodyy = {
            id: id
        }
        let options = {
        method: "DELETE",
        headers: new Headers({
            'Content-Type': 'application/json',
            'X-CSRFToken': token,
            Authorization:`Bearer ${token}`
        })
        }

        await fetch(URLq + 'activities/' + id, options)
        .then(data => {
            data.json()
            .then(json => {
                console.log(json)
            })
            .catch(error => {
                console.log(error)
            })
        })
        handleClose()

        window.location.reload();
    }
    return <>{lessonInModal ? <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>Мероприятие</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                Мероприятие: { lessonInModal.name }<br/>
                Учитель: { users.find( x => x.pk == teachers.find(x => x.id === lessonInModal.teacher).user).username  }<br/>
                Аудитория: { classRooms.find(x => x.id === lessonInModal.classroom).number }<br/>
                Начало: { lessonInModal.start_time }<br/>
                Длительность: { lessonInModal.duration }<br/>
                {lessonInModal.groups.length === 1 ? 
                'Группа: ' :
                'Группы: ' }
                {lessonInModal.groups.map(group => (
                groups.find(x => x.id === group).name
                )).join(' ')}
                </Modal.Body>

                <Modal.Footer>
                    {Admin ?
                    <>
                    <Button onClick={() => {handleClose(); handleShowULesson()}}>
                        Изменить
                    </Button>
                    <Button variant="danger" onClick={() => DeleteLesson(lessonInModal.id)}>
                        Удалить Мероприятие
                    </Button>
                    </> 
                     : <></>}
                
                <Button variant="secondary" onClick={handleClose}>
                    Ясно
                </Button>
                </Modal.Footer>
            </Modal>
            : <></>}
            </>
}