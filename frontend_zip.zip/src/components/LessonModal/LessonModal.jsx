import React from "react"
import Modal from 'react-bootstrap/Modal'

import { getFullTime } from "../../helpers/dateHalpers"
import { Button } from "../../ui"
import { URL } from '../../consts/UserData';

export const LessonModal = ({handleShowULesson, Admin, users, show, handleClose, typeLessons, teachers, classRooms, lessonInModal, groups, token}) => {
    
    
    if(Admin && show){
        console.log('Разрешаю удалять')
    }
    const DeleteLesson = async (id) => {

        let options = {
        method: "DELETE",
        headers: new Headers({
            'Content-Type': 'application/json',
            'X-CSRFToken': token,
            Authorization:`Bearer ${token}`
        })
        }

        await fetch(URL + 'lessons/' + id, options)
        .then(data => {
            data.json()
            .then(json => {
                console.log(json)
            })
            .catch(error => {
                console.log(error)
            })
        })
        handleClose()

        window.location.reload();
    }
    return <>{lessonInModal ? <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>Урок</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                Урок: { typeLessons.find(x => x.id === lessonInModal.lesson_type).name }<br/>
                Учитель: { users.find( x => x.pk == teachers.find(x => x.id === lessonInModal.teacher).user).username  }<br/>
                Аудитория: { classRooms.find(x => x.id === lessonInModal.classroom).number }<br/>
                Начало: { lessonInModal.start_time }<br/>
                Длительность: { lessonInModal.duration }<br/>
                {lessonInModal.groups.length === 1 ? 
                'Группа: ' :
                'Группы: ' }
                {lessonInModal.groups.map(group => (
                groups.find(x => x.id === group).name
                )).join(' ')}
                </Modal.Body>

                <Modal.Footer>
                    {Admin ?<>
                    <Button onClick={() => {handleClose(); handleShowULesson()}}>
                        Изменить
                    </Button>
                    <Button variant="danger" onClick={() => DeleteLesson(lessonInModal.id)}>
                        Удалить урок
                    </Button> 
                    </> : <></>}
                
                <Button variant="secondary" onClick={handleClose}>
                    Ясно
                </Button>
                </Modal.Footer>
            </Modal>
            : <></>}
            </>
}