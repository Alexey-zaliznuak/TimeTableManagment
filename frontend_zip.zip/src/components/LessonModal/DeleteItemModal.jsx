import React from "react"
import Modal from 'react-bootstrap/Modal'

import { getFullTime } from "../../helpers/dateHalpers"
import { Button } from "../../ui"
import { URL } from '../../consts/UserData';

export const DeleteItemModal = ({ show, handleClose, itemInModal, ...props}) => {
    console.log(show, handleClose, itemInModal, props)
    const tablename = itemInModal.name
    itemInModal = itemInModal.item

    const DeleteLesson = async (id) => {
        console.log(id, tablename)
        

        let options = {
        method: "DELETE",
        headers: new Headers({
            'Content-Type': 'application/json',
            'X-CSRFToken': props.token,
            Authorization:`Bearer ${props.token}`
        })
        }
        await fetch(URL + tablename + '/' + id, options)
        .then(data => {
          console.log(data)
            data.json()
              .then(json => {
                console.log(json)
                let alertt = ''
                for (const property in json) {
                  alertt += `${property}: ${json[property]}\n`
                }
                if(data.status == 204) {
                  alertt = 'Объект успешно удален'
                }
                console.log(alertt)
                alert(alertt)
                if(data.status == 204) {
                }else{
                  alert('Что-то пошло не так')
                }
              })
            })
            .finally(a => {
              window.location.reload();
            })

    }

    return <>{itemInModal ? <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                <Modal.Title>Мероприятие</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {itemInModal.id}{' '}
                    {itemInModal.pk}{' '}
                    {itemInModal.name}{' '}
                    {itemInModal.username}{' '}
                    {tablename == 'teachers' | tablename == 'students' ? props.users.find(x => x.pk == itemInModal.user).username : ''}
                </Modal.Body>

                <Modal.Footer>
                   <Button variant="danger" onClick={() => DeleteLesson(itemInModal.id ? itemInModal.id : itemInModal.username)}>
                        Удалить
                    </Button>
                
                <Button variant="secondary" onClick={handleClose}>
                    Отмена
                </Button>
                </Modal.Footer>
            </Modal>
            : <></>}
            </>
}