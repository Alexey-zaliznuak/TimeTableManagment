

export const SearchQuery = () => {
  return ''
}