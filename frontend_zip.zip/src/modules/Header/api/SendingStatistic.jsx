export const SendingStatistic = () => {
  // TODO: Sending statistics on server
  return 'True'
}