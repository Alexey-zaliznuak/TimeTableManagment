import { MOUNTH } from "../consts/Time"

export const getFullTime = (date = new Date()) => {
  return`${date.getHours()}:${
    date.getMinutes() > 10 ? date.getMinutes() : '0' + date.getMinutes()
  }`
}
export const getFullDate = (date = new Date()) => {
  return`${date.getDate()} ${MOUNTH[date.getMonth()]} ${date.getFullYear()}`
}
export const checkEqualDate = (date1 = new Date(), date2 = new Date()) => {
  return date1.getDate() === date2.getDate() 
    && date1.getMonth() === date2.getMonth() 
    && date1.getFullYear() === date2.getFullYear() 
} 