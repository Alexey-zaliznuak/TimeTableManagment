import React from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom'
import styled from 'styled-components'

import { Button, Input } from '../../ui';
import { FormWithValidate } from '../../components/FormWithValidate';

export const Registration = () => {
  const onSubmit = data => console.log(data)

  return <>
    <Body>
      <Window>
        <FormWithValidate onSubmit={onSubmit}>
          <Window.Title>Окно регистрации</Window.Title>

          <Input name="login" placeholder="Логин" validate="login"/>
          <Input name="email" placeholder="Почта" validate="email"/>
          <Input name="password"  type="password" placeholder="Пароль" validate="password"/>
          <Input name="rePassword" type="password" placeholder="Повторить пароль" validate="password"/>

          <Input name="About" type="textarea" placeholder="textarea" />
          <Input name="date" type="date" placeholder="date" />

          <RButton>Регистрация</RButton>
        </FormWithValidate>
        <Link to="/Auth">Уже зарегестрированы? Вход</Link>
      </Window >
    </Body>
  </>
}

const Body = styled.div`
  width: 100wh;
  height: 80vh;
  display: flex;
  justify-content: center;
  align-items: center;
`

const Window = styled(Card)`
  min-width: 450px;
  min-height:100px;
  width: max-content;
  height: min-content;
  padding: 40px;
  gap: 10px;
`
const RButton = styled(Button)`
  width: 150px;
  margin-left: auto;
`