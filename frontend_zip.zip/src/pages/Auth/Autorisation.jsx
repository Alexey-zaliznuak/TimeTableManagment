import React from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { COLORS } from '../../consts/style';
import myToken from '../../components/AddLessonModal/token';

import { Button, Input } from '../../ui';
import { FormWithValidate } from '../../components/FormWithValidate';


export const Authorization = (props) => {
  const onSubmit = data => {
    console.log(data)

    const URLq = 'http://26.81.229.58:8000/api/v1/'

    let options = {
      method: "POST",
      headers: new Headers({
          'Content-Type': 'application/json'
      }),
      body: JSON.stringify(data)
    }

    fetch(URLq + 'jwt/create/', options)
      .then(data => {
        data.json()
          .then(json => {
            props.setToken(json.access)
            alert('Вам доступно изменение расписания')
          })
          .catch(error => {
            console.log(error)
            alert('Что-то пошло не так')
          })
      })

  };



  return <>
    <Body>
      <Window>
        <FormWithValidate onSubmit={onSubmit}>
          <Window.Title>Окно авторизации</Window.Title>

          <Input name="username" type="text" placeholder="Логин" validate="login"/>
          <Input name="password" type="password" placeholder="Пароль" validate="password"/>

          <RButton>Авторизация</RButton>
        </FormWithValidate>
        {/* <Link to="/Reg">Еще не зарегестрированы? Регистрация</Link> */}
      </Window >
    </Body>
  </>
}

const Body = styled.div`
  width: 100wh;
  height: 90vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: ${COLORS.blue200}
`

const Window = styled(Card)`
  min-width: 450px;
  min-height:100px;
  width: max-content;
  height: min-content;
  padding: 40px;
  gap: 10px;
`
const RButton = styled(Button)`
  width: 150px;
  margin-left: auto;
`