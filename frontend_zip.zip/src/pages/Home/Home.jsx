import React, { useState, useEffect } from "react"
import styled from "styled-components"
import Modal from 'react-bootstrap/Modal';

import { DAYS, MOUNTH } from "../../consts/Time";
import { COLORS } from "../../consts/style";

import { checkEqualDate, getFullDate, getFullTime } from "../../helpers/dateHalpers";

import { Button, Select } from "../../ui";

import { FormWithValidate } from "../../components/FormWithValidate";
import { LessonModal } from "../../components/LessonModal/LessonModal"


import { SeeActivityButton } from "../../components/SeeLessonButton/SeeActivityButton"
import { ActivityModal } from "../../components/LessonModal/ActivityModal"

export const Home = ({ lessons, activities, typeLessons, teachers, groups, classRooms, date, users }) => {
  const [day, setDay] = useState(1);
  const [show, setShow] = useState(false);
  const [lessonId, setLessonId] = useState(1)
  const [lessonInModal, setLesson] = useState(lessons[0])
  
  const DOptions = [
    { value: 1, label: 'Понедельник 1' },
    { value: 2, label: 'Вторник 1' },
    { value: 3, label: 'Среда 1' },
    { value: 4, label: 'Четверг 1' },
    { value: 5, label: 'Пятница 1' },
    { value: 6, label: 'Суббота 1' },
    { value: 8, label: 'Понедельник 2' },
    { value: 9, label: 'Вторник 2' },
    { value: 10, label: 'Среда 2' },
    { value: 11, label: 'Четверг 2' },
    { value: 12, label: 'Пятница 2' },
    { value: 13, label: 'Суббота 2' },
    { value: 7, label: 'Воскресение 1' },
    { value: 14, label: 'Воскресение 2' },
  ]

  useEffect(() => {
    setLesson(lessons.find(x=> x.id === lessonId))
    console.log(lessonId)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);

  const handleClose = () => {
    setShow(false)
  }
  const handleShow = (id) => {
    setLessonId(id)
    setShow(true)
  }

  const [showA, setShowA] = useState(false)
  const [activityId, setActivityId] = useState(activities[0].id)
  const [ActivityInModal, setActivity] = useState(activities[0])
  useEffect(() => {
      setActivity(activities.find(x=> x.id === activityId))
      console.log(activities, activityId)
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activityId]);
  const handleCloseA = () => {
    setShowA(false)
  }
  const handleShowA = (id) => {
    setActivityId(id)
    setShowA(true)
  }


  const onSubmit = data => {
    setDay(data.day)
  }
  return (
    <Page className="bg-blue-100">
      <div style={{display: "flex", backgroundColor: COLORS.blue200}}>

        
      <FormWithValidate style={{flexDirection: 'row'}} onSubmit={onSubmit}>
        <Select name="day" placeholder="День" options={DOptions}/>
        <Button>Посмотреть</Button>
      </FormWithValidate>
      </div>


      <Main>
        {groups.map(group => (
          <Block key={group.id}>
            {group.name}
            {lessons.filter(x => x.day == day)
                    .filter(x => x.groups.includes(group.id))
                    .map((lesson, i) => (
                        <SeeLessonButton key={i} onClick={() => handleShow(lesson.id)}>
                          { typeLessons.find(x => x.id === lesson.lesson_type).name } {' '}
                          { lesson.start_time }
                        </SeeLessonButton>
            ))}
            {activities.filter(x => x.day == day)
                    .filter(x => x.groups.includes(group.id))
                    .map(active => {
                  return <div key={active.id}>
                    <SeeActivityButton 
                      lessonInModal={ActivityInModal}   
                      handleShow={handleShowA} 
                      classRooms={classRooms} 
                      settings={['time', 'group']}
                      lesson={active} 
                      groups={groups}
                    />
                    
                  </div>
                })}
          </Block>
        ))
        .reduce((prev, curr, i) => [prev, <Border key={i}/>, curr], '')
        }
        <ActivityModal 
                      lessonInModal={ActivityInModal} 
                      handleClose={handleCloseA} 
                      classRooms={classRooms} 
                      teachers={teachers} 
                      groups={groups}
                      show={showA} 
                      users={users}
                    />
        <LessonModal show={show} handleClose={handleClose} users={users} typeLessons={typeLessons} teachers={teachers} classRooms={classRooms} lessonInModal={lessonInModal} groups={groups}/>
      </Main>
    </Page>
  )
}

const SeeLessonButton = styled(Button) `
  height: min-content;
  font-size: 14px;
`
const Page = styled.div `
    min-height: 80vh;
`
const Main = styled.div`
    
`
const Border = styled.div `
  width: 90%;
  height: 1px;
  margin: auto;
  background-color: transparament;
`
const Block = styled.div `
  display: flex;
  justify-content: start;
  gap: 10px;
  align-items: center;
  width: 100%;
  background-color: ${COLORS.blue200};
  min-height: 100px;
  border: none;

  &:last-child {
    border: none;
  }
`


// {lessons.filter(x => checkEqualDate(new Date(x.start_time), MyDate)).map(lesson => (
//   <Block key={lesson.id}>
//     Урок: { typeLessons.find(x => x.id === lesson.lessonType).name }<br/>
//     Учитель: { teachers.find(x => x.id === lesson.teacher).name }<br/>
//     Время: { getFullTime( new Date(lesson.start_time * 1000) )} { getFullTime( new Date((lesson.start_time + lesson.duration) * 1000) )}<br/>
//     {lesson.groups.length === 1 ? 
//     'Группа: ' :
//     'Группы: ' }
//     {lesson.groups.map(group => (
//       groups.find(x => x.id === group).name
//     )).join(' ')}
//   </Block>
// ))
// .reduce((prev, curr) => [prev, <Border/>, curr], '')
// }