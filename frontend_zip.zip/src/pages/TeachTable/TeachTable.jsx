import React, { useState, useEffect, useCallback, useMemo } from "react"

import styled from "styled-components"
import Modal from 'react-bootstrap/Modal'
import Card from 'react-bootstrap/Card'

import { DAYS, MOUNTH } from "../../consts/Time"
import { COLORS } from "../../consts/style"

import { checkEqualDate, getFullDate, getFullTime } from "../../helpers/dateHalpers"

import { Button } from "../../ui"
import { LessonModal } from "../../components/LessonModal/LessonModal"
import { SeeLessonButton } from "../../components/SeeLessonButton/SeeLessonButton"

export const TeachTable = ({ lessons, typeLessons, teachers, groups, classRooms }) => {

  const MyDate = new Date()
  const [show, setShow] = useState(false);

  const [date, setDate] = useState(MyDate.getTime())
  const [week, setWeek] = useState([])
  const [teachId, setTeachId] = useState(1)

  const [lessonId, setLessonId] = useState(1)
  const [lessonInModal, setLesson] = useState(lessons[0])
  
  useEffect(() => {
    setLesson(lessons.find(x=> x.id === lessonId))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);

  useEffect(()=> {
    const nowday = new Date(date).getDay()
    
    const differenceInWeek = [1, 2, 3, 4, 5, 6].map(x => (x-nowday))
    setWeek(differenceInWeek.map(x => {
      const datei = new Date(date)
      datei.setDate(datei.getDate() + x)
      return datei
    }))

  }, [date])

  const cloasd = () => {
    const qweDarew = new Date(date)
    qweDarew.setDate(qweDarew.getDate() + 1)
    setDate(qweDarew.getTime())
  }

  
  const handleClose = () => {
    setShow(false)
  }
  const handleShow = (id) => {
    setLessonId(id)
    setShow(true)
  }

  
  return (
      <Page className="bg-blue-100">
    <Main>
      {week.map((day, i) => {
          const lessonsOnDay = lessons.filter( x => checkEqualDate(new Date(x.start_time), new Date(day)))
          .filter(x => x.teacher === teachId)
          
          console.log(lessonsOnDay)
          
        return <Card style={{width:"20rem"}} key={i}>
          <Card.Header>{DAYS[day.getDay()? day.getDay()- 1 : 6]}</Card.Header>
          <Card.Body>
            {lessonsOnDay.map(lesson => {
              return <div key={lesson.id}>
                <SeeLessonButton lesson={lesson} handleShow={handleShow} typeLessons={typeLessons}  classRooms={classRooms} lessonInModal={lessonInModal} groups={groups}
                  settings={['time', 'group']}
                
                />

                <LessonModal show={show} handleClose={handleClose} typeLessons={typeLessons} teachers={teachers} classRooms={classRooms} lessonInModal={lessonInModal} groups={groups}/>
              </div>
      })
      }
          </Card.Body>
        </Card>
      })}
    </Main>
  </Page>
  )
}

const Page = styled.div `
  min-height: 80vh;
  padding: 10px;
`
const Main = styled.div`
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, 1fr);
  justify-items: center;
`
const Border = styled.div `
  width: 90%;
  height: 1px;
  margin: auto;
  background-color: transparament;
`