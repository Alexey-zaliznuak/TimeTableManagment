import React, { useState, useEffect } from "react"

import styled from "styled-components"
import Card from 'react-bootstrap/Card'

import { DAYS } from "../../consts/Time"
import { COLORS } from "../../consts/style"

import { FormWithValidate } from "../../components/FormWithValidate"
import { Button, Select } from "../../ui"
import { checkEqualDate } from "../../helpers/dateHalpers"

import { LessonModal } from "../../components/LessonModal/LessonModal"
import { SeeLessonButton } from "../../components/SeeLessonButton/SeeLessonButton"

import { SeeActivityButton } from "../../components/SeeLessonButton/SeeActivityButton"
import { ActivityModal } from "../../components/LessonModal/ActivityModal"

export const IndividualTimeTable = ({ users, lessons, activities, typeLessons, teachers, groups, classRooms, UserId, UserType, setUserId, settings, date}) => {

  const [lessonInModal, setLesson] = useState(lessons[0])
  const [lessonId, setLessonId] = useState(1)
  const [show, setShow] = useState(false)
  const [week, setWeek] = useState([])
  
  useEffect(() => {
    setLesson(lessons.find(x=> x.id === lessonId))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);

  useEffect(()=> {
    const nowday = new Date(date).getDay()
    
    const differenceInWeek = [1, 2, 3, 4, 5, 6].map(x => (x-nowday))
    setWeek(differenceInWeek.map(x => {
      const datei = new Date(date)
      datei.setDate(datei.getDate() + x)
      return datei
    }))

  }, [date])

  
  const handleClose = () => {
    setShow(false)
  }
  const handleShow = (id) => {
    setLessonId(id)
    setShow(true)
  }

const [showA, setShowA] = useState(false)
const [activityId, setActivityId] = useState(activities[0].id)
const [ActivityInModal, setActivity] = useState(activities[0])
useEffect(() => {
    setActivity(activities.find(x=> x.id === activityId))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activityId]);
const handleCloseA = () => {
    setShowA(false)
  }
  const handleShowA = (id) => {
    setActivityId(id)
    setShowA(true)
  }

  const DOptions = [
    { value: 1, label: 'Понедельник 1' },
    { value: 2, label: 'Вторник 1' },
    { value: 3, label: 'Среда 1' },
    { value: 4, label: 'Четверг 1' },
    { value: 5, label: 'Пятница 1' },
    { value: 6, label: 'Суббота 1' },
    { value: 8, label: 'Понедельник 2' },
    { value: 9, label: 'Вторник 2' },
    { value: 10, label: 'Среда 2' },
    { value: 11, label: 'Четверг 2' },
    { value: 12, label: 'Пятница 2' },
    { value: 13, label: 'Суббота 2' },
    { value: 7, label: 'Воскресение 1' },
    { value: 14, label: 'Воскресение 2' },
  ]
  const GOptions = groups.map(group => ( 
    { value: group.id, label: group.name } 
  ))
  const TOptions = teachers.map(teach => (
    { value: teach.id, label: users.find(x => x.pk == teach.user).username }
  ))
  const  onSubmit = data => {
    setUserId(+data.group)
    console.log(data)
  }
  return (
    <Page className="bg-blue-100">
       <div style={{display: "flex", backgroundColor: COLORS.blue200}}>
        {UserType != "teacher" ? <FormWithValidate style={{flexDirection: 'row'}} onSubmit={onSubmit}>
            <Select name="group" placeholder="Группа" options={GOptions}/>
            <Button>Посмотреть</Button>
          </FormWithValidate> :

            <FormWithValidate style={{flexDirection: 'row'}} onSubmit={onSubmit}>
              <Select name="group" placeholder="Учитель" options={TOptions}/>
              <Button>Посмотреть</Button>
            </FormWithValidate> 
          }
          
          </div>

      <Main>
        {DOptions.map((day, i) => {
          const lessonsOnDay = lessons
            .filter( x => x.day == day.value)
            .filter(x => {
                if (typeof x[UserType] != 'object') return x[UserType] == UserId 
                else return x[UserType].includes(UserId)
              })
          const actvityOnDay = activities
              .filter( x => x.day == day.value)
              .filter(x => {
                  if (typeof x[UserType] != 'object') return x[UserType] == UserId 
                  else return x[UserType].includes(UserId)
                })
          return (
            <Card style={{width:"20rem"}} key={i}>
              <Card.Header>{day.label}</Card.Header>
              <Card.Body>
                {lessonsOnDay.map(lesson => {
                  return <div key={lesson.id}>
                    <SeeLessonButton 
                      lessonInModal={lessonInModal} 
                      typeLessons={typeLessons}  
                      handleShow={handleShow} 
                      classRooms={classRooms} 
                      settings={settings}
                      lesson={lesson} 
                      groups={groups}
                    />
                    <LessonModal 
                      lessonInModal={lessonInModal} 
                      handleClose={handleClose} 
                      typeLessons={typeLessons} 
                      classRooms={classRooms} 
                      teachers={teachers} 
                      groups={groups}
                      show={show} 
                      users={users}
                    />
                  </div>
                })}
                {actvityOnDay.map(active => {
                  return <div key={active.id}>
                    <SeeActivityButton 
                      lessonInModal={ActivityInModal}   
                      handleShow={handleShowA} 
                      classRooms={classRooms} 
                      settings={['time', 'group']}
                      lesson={active} 
                      groups={groups}
                    />
                    <ActivityModal 
                      lessonInModal={ActivityInModal} 
                      handleClose={handleCloseA} 
                      classRooms={classRooms} 
                      teachers={teachers} 
                      groups={groups}
                      show={showA} 
                      users={users}
                    />
                  </div>
                })}
              </Card.Body>
            </Card>
          )
        })}
      </Main>
    </Page>
  )
}

const Page = styled.div `
  min-height: 80vh;
  padding: 10px;
`
const Main = styled.div`
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, 1fr);
  justify-items: center;
`