import { Home } from './Home'
import { Admin } from './Admin'
import { IndividualTimeTable } from './IndividualTimeTable'
import { Authorization, Registration } from './Auth'

import { Route, Routes } from 'react-router-dom'

export const Navigation = (props) => {
  return (
    <Routes>
      <Route path='*' element={<Home {...props}/>}/>
      <Route path='Home' element={<Home {...props}/>}/>
      <Route path='Admin' element={<Admin {...props}/>}/>
      <Route path='Reg' element={<Registration {...props}/>}/>
      <Route path='Auth' element={<Authorization {...props}/>}/>
      <Route path='TimeTable' element={<IndividualTimeTable {...props} UserType="groups" settings={[]}/>}/>
      <Route path='TeachTable' element={<IndividualTimeTable {...props} UserType="teacher" settings={['time', 'group']}/>}/>
    </Routes>
  )
}