import { Button, HideButton, Select } from '../../../ui'
import styled from 'styled-components'

export const AsideItem = ({name, ...props}) => {

    return <SButton {...props} style={{width: '95%', marginLeft: 0}}>
                {name}
                {/* <Button  style={{ marginLeft: 'auto', width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                    <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
                </svg>
                </Button> */}
                <Button  style={{ marginLeft: 'auto', width: '36px', height:'36px', padding: 0, borderRadius: '50%', marginTop: '3px' }}>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="32" fill="currentColor" className="bi bi-plus-circle-fill" viewBox="0 0 16 16">
                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168l10-10zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207 11.207 2.5zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293l6.5-6.5zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325z"/>
                </svg>
                </Button>
            </SButton>
    
}

const SButton = styled.div`
  display: flex;
  width: 80%;

  background-color:  ${props => props.active ? "rgba(232,240,254, .9)": "transparent"};
  color: ${props => props.active ? "rgb(24,90,188)": "#003153"};
  font-size: 1em;

  padding:  6px 0 6px 3px;
  margin: 0 -5px;

  border: none;
  border-radius: 0 5px 5px 0;
  
  text-align: start;
  justify-content: start;
  align-items:center;
  
  transition: all .2s;

  & > * {
    margin: 0 5px;
  }

  ${props => props.active ? "": "&:hover {background-color: rgba(0,0,0,0.1);}"}
  
`