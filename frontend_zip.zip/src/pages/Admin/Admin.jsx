import React, { useState, useEffect } from 'react'
import styled from 'styled-components'
import { FormWithValidate } from '../../components/FormWithValidate'
import Table from 'react-bootstrap/Table';
import Form from 'react-bootstrap/Form';
import { AsideItem } from './components/AsideItem'

import { AddLessonModal } from '../../components/AddLessonModal';
import { LessonModal } from "../../components/LessonModal/LessonModal";
import { ActivityModal } from "../../components/LessonModal/ActivityModal";

import { SeeLessonButton } from "../../components/SeeLessonButton/SeeLessonButton"
import { SeeActivityButton } from "../../components/SeeLessonButton/SeeActivityButton"

import Card from 'react-bootstrap/Card'

import { COLORS } from '../../consts/style'
import { Button, HideButton, Select } from '../../ui'
import { AddGroupModal } from '../../components/AddLessonModal/AddGroupModal';
import { AddUserModal } from '../../components/AddLessonModal/AddUserModal';
import { AddTeacherModal } from '../../components/AddLessonModal/AddTeacherModal';
import { AddStudentModal } from '../../components/AddLessonModal/AddStudentModal';
import { AddLessonTypes } from '../../components/AddLessonModal/AddLessonTypes';
import { AddClassRoomsModal } from '../../components/AddLessonModal/AddClassRoomsModal';
import { AddActivitiesModal } from '../../components/AddLessonModal/AddActivitiesModal';
import { ULessonModal } from '../../components/AddLessonModal/ULessonModal';
import { UActivityModal } from '../../components/AddLessonModal/UActivityModal';

import Cookies from 'universal-cookie';

import { DeleteItemModal } from '../../components/LessonModal/DeleteItemModal'
import { UTeacherModal } from '../../components/AddLessonModal/UTeacerModal';

export const Admin = (props) => {
  console.log(props)
  const cookies = new Cookies();

  const [ groupId, setGroupId ] = useState(1)
  const [ dayId, setDayId ] = useState(1)
  const [ rowId, setRowId ] = useState(undefined)

  const [tableName, setTableName] = useState(cookies.get('tableName') ? cookies.get('tableName') :'student')
  const [table, setTable ] = useState(<></>)
  const [isTable, setIsTable ] = useState(cookies.get('isTable'))

  console.log('isTable', isTable, cookies.get('isTable'))
  const getTable = (e, name) => {
    setTableName(name)
    setIsTable(true)
  }
  const getTimetables = (e) => {
    setIsTable(false)
  }
  useEffect(() => {
    cookies.set('tableName', tableName, { path: '/' });
    cookies.set('isTable', isTable, { path: '/' })
    console.log(isTable)
  }, [tableName, isTable]);

  const renderData = {
    teacher: props.teachers,
    student: props.students,
    methodist: props.methodists,
    groups: props.groups,
    users: props.users
  }[tableName]

  const GOptions = props.groups.map(group => ( { value: group.id, label: group.name } ))
  const DOptions = [
    { value: 1, label: 'Понедельник 1' },
    { value: 2, label: 'Вторник 1' },
    { value: 3, label: 'Среда 1' },
    { value: 4, label: 'Четверг 1' },
    { value: 5, label: 'Пятница 1' },
    { value: 6, label: 'Суббота 1' },
    { value: 8, label: 'Понедельник 2' },
    { value: 9, label: 'Вторник 2' },
    { value: 10, label: 'Среда 2' },
    { value: 11, label: 'Четверг 2' },
    { value: 12, label: 'Пятница 2' },
    { value: 13, label: 'Суббота 2' },
    { value: 7, label: 'Воскресение 1' },
    { value: 14, label: 'Воскресение 2' },
  ]

  const TableOptions = {
    teacher: {
      id: {
        name: '#',
        noneDitable: true,
      },
      user: {
        link: 'users',
      },
      work_days: {
        name: 'рабочие дни'
      }
    },
    student: {
      id: {
        name: '#',
        noneDitable: true,
      },
      user: {
        link: 'users',
      },
      group: {
        link: 'groups',
      }
    },
    methodist: {
      id: {
        name: '#',
        noneDitable: true,
      },
      user_id: {
        link: 'users',
      },
    },
    groups: {
      name: {
        name: 'Группа'
      }
    },
    users: {
      username: {
        name: 'Имя'
      },
      role: {
        name: 'Роль'
      },
      first_name: {
        name: 'Полное имя'
      },
      last_name: {
        name: 'Фамилия'
      }
    },
    '': {}
  }

  const Days = {
    monday: 'Понедельник',
    tuesday: 'Вторник',
    wednesday: 'Среда',
    thursday: 'Четверг',
    friday: 'Пятница',
    saturday: 'Суббота',
    sunday: 'Воскресение'

  }
  const generator = (item) => {
    return cellGenerator(item, tableName)

  }
  const cellGenerator = (item, table) => {
    let cell = []
    for (const [key, value] of Object.entries(item)) {
      const cellSet = TableOptions[table][key]
      if(!cellSet) continue
      const link = cellSet.link

      if(link) {
        if(link == 'users') {
          cell.push(...cellGenerator(props[link].find(x => x.pk === value), link))

        }else{
          cell.push(...cellGenerator(props[link].find(x => x.id === value), link))
        }
      }
      else if(key == 'role'){
        cell.push(<td >{value.name}</td>)
      }
      else if(key == 'work_days'){
        cell.push(<td >{value.map((x, id) => Days[x]).join(', ')}</td>)
      }
      else{
        cell.push(<td >{value}</td>)
      }
    }
    return cell
  }
  const headGenerator = (item, table) => {
    let cell = []
    for (const [key, value] of Object.entries(item)) {
      const cellSet = TableOptions[table][key]
      if(!cellSet) continue
      const link = cellSet.link
      if(link) {
        if(link == 'users') {
          cell.push(...headGenerator(props[link].find(x => x.pk === value), link))

        }else{
          cell.push(...headGenerator(props[link].find(x => x.id === value), link))
        }
      }else{
        cell.push(<td >{TableOptions[table][key].name}</td>)
      }
    }
    return cell
  }

  const changeData = (data) => {
    const dataDecorator = {
      'groupId' : setGroupId,
      'dayId' : setDayId,
    }
    for (const [key, value] of Object.entries(data)) {
      dataDecorator[key](+value)
    }
  }

  useEffect(() => {
  }, [groupId, dayId]);

  const selectRow = (event, id, w) => {
    setRowId(id)
  }

  useEffect(() => {
    setTable( <>
      <thead>
        <tr>
          {headGenerator(renderData[0], tableName)}
        </tr>
      </thead>
      <tbody>
        {renderData.map((el, row) => (
          
            <tr 
              style={{
                // backgroundColor: `${ rowId === el.id ? COLORS.blue500 : 'transparent'}` 
                backgroundColor: 'transparent'
              }} 
              key={row} 
              onClick={(event) => selectRow(event, el.id ? el.id : el.pk, renderData)}
              >
              { generator(el) }
            </tr>
          
        ))}
      </tbody>
    </>)
  }, [tableName]);
  


  const [show, setShow] = useState(false)
  const [showA, setShowA] = useState(false)
  const [showAddLessonModal, setShowAddLessonModal] = useState(false)
  const [lessonId, setLessonId] = useState(props.lessons[0].id)
  const [activityId, setActivityId] = useState(props.activities[0].id)
  const [lessonInModal, setLesson] = useState(props.lessons[0])
  const [ActivityInModal, setActivity] = useState(props.activities[0])

  useEffect(() => {
    setActivity(props.activities.find(x=> x.id === activityId))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activityId]);

  useEffect(() => {
    setLesson(props.lessons.find(x=> x.id === lessonId))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lessonId]);
  
  const handleCloseAddLesson = () => {
    setShowAddLessonModal(false)
  }
  const handleShowAddLesson = (id) => {
    setShowAddLessonModal(true)
  }
  
  
  const [showAddLessonTypes, setShowAddLessonTypes] = useState(false)
  const handleCloseAddLessonTypes = () => {
    setShowAddLessonTypes(false)
  }
  const handleShowAddLessonTypes = (id) => {
    setShowAddLessonTypes(true)
  }

  const [showAddActivitiesModal, setShowAddActivities] = useState(false)
  const handleCloseAddActivities = () => {
    setShowAddActivities(false)
  }
  const handleShowAddActivities = (id) => {
    setShowAddActivities(true)
  }

  const [showAddClassroom, setShowAddClassroom] = useState(false)
  const handleCloseAddClassroom = () => {
    setShowAddClassroom(false)
  }
  const handleShowAddClassroom = (id) => {
    setShowAddClassroom(true)
  }

  const handleClose = () => {
    setShow(false)
  }
  const handleShow = (id) => {
    setLessonId(id)
    setShow(true)
  }
  const handleCloseA = () => {
    setShowA(false)
  }
  const handleShowA = (id) => {
    setActivityId(id)
    setShowA(true)
  }
  
  const [showULesson, setShowULesson] = useState(false)
  const handleCloseULesson = () => {
    setShowULesson(false)
  }
  const handleShowULesson = () => {
    setShowULesson(true)
  }

  const [showUActivity, setShowUActivity] = useState(false)
  const handleCloseUActivity = () => {
    setShowUActivity(false)
  }
  const handleShowUActivity = () => {
    setShowUActivity(true)
  }
  
  
  const [showU, setShowU] = useState(false)
  const handleCloseU = () => {
    setShowU(false)
  }
  const handleU = () => {
    const DeleteDecorator = {
      student: {
        name: 'students',
        item: props.students.find(x => x.id == rowId)
      },
      teacher: {
        name: 'teachers',
        item: props.teachers.find(x => x.id == rowId)
      },
      groups: {
        name: 'groups',
        item: props.groups.find(x => x.id == rowId)
      },
      users: {
        name: 'users',
        item: props.users.find(x => x.pk == rowId)
      },
    }
    setItemInModal(DeleteDecorator[tableName])
    setShowU(true)
  }

  const [itemInModal, setItemInModal] = useState(props.groups[0])
  const [showDelete, setShowDelete] = useState(false)
  const deleteItem = () => {
    console.log(rowId, tableName, itemInModal)
    console.log(props.students)

    const DeleteDecorator = {
      student: {
        name: 'students',
        item: props.students.find(x => x.id == rowId)
      },
      teacher: {
        name: 'teachers',
        item: props.teachers.find(x => x.id == rowId)
      },
      groups: {
        name: 'groups',
        item: props.groups.find(x => x.id == rowId)
      },
      users: {
        name: 'users',
        item: props.users.find(x => x.pk == rowId)
      },
    }
    setItemInModal(DeleteDecorator[tableName])
    setShowDelete(true)
  }
  const handleCloseDelete = () => {
    setShowDelete(false)
  }

  return(
    <Main>
      <AdminWindow>
        <Aside>
          <Block>
            <BlockHeader>
              Аккаунты
            </BlockHeader>
            <BlockBody>

              <AsideItem onClick={(e) => getTable(e, 'student')} name="Студенты"/>
              <AsideItem onClick={(e) => getTable(e, 'teacher')} name="Учителя"/>
              <AsideItem onClick={(e) => getTable(e, 'groups')} name="Группы"/>
              <AsideItem onClick={(e) => getTable(e, 'users')} name="Пользователи"/>
              {/* <AsideItem onClick={(e) => getTable(e, 'methodists')} name="admins"/> */}
            </BlockBody>
          </Block>

          <Block>
            <BlockHeader>
              Группы
            </BlockHeader>
            <BlockBody>
              <AsideItem onClick={getTimetables} name="Расписание"/>
            </BlockBody>
          </Block>

        </Aside>
        <WorkPlace>
          <WorkHeader>

            {!isTable ? <>
              
              </> : <>
            
              <span style={{margin: "0 10px 0 0"}}>Строка: {rowId ? rowId : 'Выберете' }</span>
              {rowId ? <>
              <Button style={{margin: "0 10px 0 0"}} onClick={deleteItem}>Удалить </Button>

              </>
               : <></>}
              <DeleteItemModal show={showDelete} handleClose={handleCloseDelete} itemInModal={itemInModal} {...props}/>
              {tableName == 'groups' ? <>
              <Button onClick={handleShowAddLesson}>
                Добавить Группу
              </Button>
              <AddGroupModal {...props} show={showAddLessonModal} handleClose={handleCloseAddLesson}/>
              </> : <></>}

              {tableName == 'users' ? <>
              <Button onClick={handleShowAddLesson}>
                Добавить Пользователя
              </Button>
              <AddUserModal {...props} show={showAddLessonModal} handleClose={handleCloseAddLesson}/>
              </> : <></>}

              {tableName == 'student' ? <>
              <Button onClick={handleShowAddLesson}>
                Добавить Студента
              </Button>
              <AddStudentModal {...props} show={showAddLessonModal} handleClose={handleCloseAddLesson}/>
              </> : <></>}

              {tableName == 'teacher' ? <>
              <Button style={{margin: "0 10px 0 0"}} onClick={handleU}>Изменить </Button>
              <UTeacherModal show={showU} handleClose={handleCloseU} itemInModal={itemInModal} {...props}/>

              <Button onClick={handleShowAddLesson}>
                Добавить Учителя
              </Button>

              <AddTeacherModal {...props} show={showAddLessonModal} handleClose={handleCloseAddLesson}/>
              </> : <></>}
            </>
            }

          </WorkHeader>
          <WorkBody>
            {isTable ? 
            <>
                
              <Table hover striped>
                { table }
              </Table>
            </>:
              <>
                <WorkHeader>
                  <AdminForm onSubmit={changeData}>
                    <SelectGroup
                      myColor={COLORS.blue500}
                      // hoverColor={COLORS.blue600}
                      // focusColor={COLORS.blue600}
                      name='groupId' placeholder="Выберете группу" options={GOptions}/>
                    
                    <Button style={{ maxHeight: '100px', width: '150px' }}>Показать </Button>
                    
                    <ULessonModal  {...props} lessonInModal={lessonInModal} show={showULesson} handleClose={handleCloseULesson}/>
                    <UActivityModal  {...props} lessonInModal={ActivityInModal} show={showUActivity} handleClose={handleCloseUActivity}/>

                    <ButtonGroupWorker>
                      <Button onClick={handleShowAddLesson}>
                        Добавить урок
                      </Button>
                      <AddLessonModal  {...props} show={showAddLessonModal} handleClose={handleCloseAddLesson}/>

                      <Button style={{maxHeight: '100px'}} onClick={handleShowAddActivities}>
                        мероприятие
                      </Button>
                      <AddActivitiesModal  {...props} show={showAddActivitiesModal} handleClose={handleCloseAddActivities}/>
                    </ButtonGroupWorker>
                      
                      <Button style={{maxHeight: '100px'}} onClick={handleShowAddLessonTypes}>
                        Добавить дисциплину
                      </Button>
                      <AddLessonTypes  {...props} show={showAddLessonTypes} handleClose={handleCloseAddLessonTypes}/>

                      <Button style={{maxHeight: '100px'}} onClick={handleShowAddClassroom}>
                        Добавить аудиторию
                      </Button>
                      <AddClassRoomsModal  {...props} show={showAddClassroom} handleClose={handleCloseAddClassroom}/>

                  </AdminForm> 
                </WorkHeader>
                <Worker>
                  {DOptions.map((el, i) => {
                    const lessons = props.lessons.filter(x => x.groups.includes(groupId))
                                                  .filter(x => x.day == el.value)
                    const activities = props.activities.filter(x => x.groups.includes(groupId))
                                                        .filter(x => x.day == el.value)
                    return<>
                      <Card style={{width:"20rem"}} key={i}>
                      <Card.Header>{el.label}</Card.Header>
                          {lessons.map(lesson => {
                            
                            return <div key={lesson.id}>
                            <SeeLessonButton
                              lessonInModal={lessonInModal} 
                              typeLessons={props.typeLessons}  
                              handleShow={handleShow} 
                              classRooms={props.classRooms} 
                              settings={['time', 'group']}
                              lesson={lesson} 
                              groups={props.groups}
                            />
                            <LessonModal
                              handleShowULesson={handleShowULesson}
                              token={props.token}
                              Admin={true}
                              lessonInModal={lessonInModal} 
                              handleClose={handleClose} 
                              typeLessons={props.typeLessons} 
                              classRooms={props.classRooms} 
                              teachers={props.teachers} 
                              groups={props.groups}
                              show={show} 
                              users={props.users}
                            />
                          </div>
                          })}
                          {activities.map(active => {
                            return <div key={active.id}>
                            <SeeActivityButton 
                              lessonInModal={ActivityInModal}   
                              handleShow={handleShowA} 
                              classRooms={props.classRooms} 
                              settings={['time', 'group']}
                              lesson={active} 
                              groups={props.groups}
                            />
                            <ActivityModal 
                              handleShowULesson={handleShowUActivity}
                              token={props.token}
                              Admin={true}
                              lessonInModal={ActivityInModal} 
                              handleClose={handleCloseA} 
                              classRooms={props.classRooms} 
                              teachers={props.teachers} 
                              groups={props.groups}
                              show={showA} 
                              users={props.users}
                            />
                          </div>
                          })}
                      </Card>
                      </>
                    })}
                </Worker>
              </>
              }
          </WorkBody>
        </WorkPlace>
      </AdminWindow>
    </Main>
  )
}
const ButtonGroupWorker = styled.div`
  display: flex;
  flex-direction: column;
`
const Worker = styled.div`
  display: grid;
  gap: 10px;
  grid-template-columns: repeat(2, 1fr);
  justify-items: center;
`
const Block = styled.div`
  width:100%;
  min-height: 80px;
  background-color: ${ COLORS.blue200 };
`
const BlockHeader = styled.div`
  width:100%;
  min-height: 40px;
  background-color: ${ COLORS.blue300 };
  padding: 10px;
  font-size: 18px;
`
const BlockBody = styled.div`
  width:100%;
  min-height: 40px;
  background-color: transparent;
  display: flex;
  flex-direction: column;
  align-items: start;
`
const Main = styled.div`
  display: flex;
  justify-content: center;
  background-color: ${ COLORS.blue200 };
  min-height: 90vh;
  min-width: max-content;    
  width: 100%;
`
const AdminWindow = styled.div`
  display:flex;
  max-width: 1450px;
  min-width: 90%;
  min-height: 700px;
  height: max-content;
  width: min-content; 
  background-color: ${ COLORS.blue300 };
`
const Aside = styled.div`
  display: flex;
  gap: 10px;
  flex-direction: column;
  width: min-content;
  min-width: 360px;
  min-height: 700px;
  height:100%;
  background-color: ${ COLORS.blue400 };
  padding:15px 10px 10px 10px;
`
const WorkPlace = styled.div`
  width: 100%;
  min-height: 700px;
  height:100%;
  background-color: transparent;
`
const WorkHeader = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 10px 0;
  width:100%;
  min-height: 60px;
  background-color: ${ COLORS.blue400 };
`
const WorkBody = styled.div`
  width: 100%;
  min-height: 88vh;
`
const AdminForm = styled(FormWithValidate)`
  display: flex;
  flex-direction: row;
  align-items: center;
`
const SelectGroup = styled(Select)`
  width: 210px;
`




