import React, { useState, useEffect } from "react"
import { Button, Select } from "./ui";
import styled from "styled-components"
import Cookies from 'universal-cookie';

import DropdownButton from 'react-bootstrap/DropdownButton';
import Dropdown from 'react-bootstrap/Dropdown';

import { Navigation } from './pages'
import { Header } from './modules'
import { FormWithValidate } from "./components/FormWithValidate";
import { URL } from "./consts/UserData";
import { AddLessonModal } from "./components/AddLessonModal"; 
import Calendar from 'moedim';
import { getFullDate } from "./helpers/dateHalpers";
import { COLORS } from "./consts/style";

export function App() {

  const usersQ = [
    {
      id:1,
      first_name: "Галина Геннадьевна",
      role:'teacher',
      role_id: 1,
      
    }, 
    {
      id:2,
      first_name: "Алексей Романович",
      role:'teacher',
      role_id: 2,
    },
    {
      id:3,
      first_name: "Вася Пупкин",
      role:'student',
      role_id: 1,
    },
    {
      id:4,
      first_name: "Саня Долгопятов",
      role:'student',
      role_id: 2,
    },
    {
      id:5,
      first_name: "Хакер 322",
      role:'methodist',
      role_id: 1,
    },
  ]
  const teachersQ = [
    {
      id: 1,
      user: 2,
      work_days: ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"],
    },
    {
      id: 2,
      user: 3,
      work_days: ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"],
    },
  ]
  const studentsQ = [
    {
      id: 1,
      user_id: 3,
      group: 1
    },
    {
      id: 2,
      user_id: 4,
      group: 2
    },
  ]
  const methodistsQ = [
    {
      id: 1,
      user_id: 5
    }
  ]
  const groupsQ = [
    {
      id: 1,
      name: "10A"
    },
    {
      id: 2,
      name: "6B"
    }
  ]
  const classRoomsQ = [
    {
      id: 1,
      number: "314"
    },
    {
      id: 2,
      number: "215"
    }
  ]
  const typeLessonsQ = [
    {
      id: 1,
      name: "Химия"
    },
    {
      id: 2,
      name: "Открытый урок"
    },
  ]
  const lessonsQ = [
    {
      id: 1,
      groups: [1, 2],
      teacher: 4,
      classroom:1,
      lesson_type: 1,
      start_time: "09:54:05",
      duration: "00:54:06",
      day: 1
    },
    {
      id: 2,
      groups: [1],
      classroom:1,
      teacher: 4,
      lesson_type: 2,
      start_time: "09:54:05",
      duration: "00:54:06",
      day: 1,
      subgroup: 1

    },
    {
      id: 3,
      teacher: 1,
      classroom:2,
      groups: [1, 2],
      lesson_type: 2,
      start_time: "09:54:05",
      duration: "00:54:06",
      day: 1
    },
  ]
  const ActivitiesQ = [
    {
      name: 'name',
      describe: 'describe',
      groups: [1, 2],
      teacher: 1,
      classRoom:2,
      start_time: 1679346951465,
      duration: 5400,
      day: 1
    }
  ]


  const [lessons, setLessons] = useState([])
  const [users, setUsers] = useState([])
  const [teachers, setTeachers] = useState([])
  const [groups, setGroups] = useState([])
  const [typeLessons, setTypeLessons] = useState([])
  const [classRooms, setClassRooms] = useState([])
  const [students, setStudents] = useState([])
  const [methodists, setMethodists] = useState([])
  const [activities, setActivities] = useState([])
  
  
  useEffect(() => {
    Request('lessons', setLessons)
    Request('users', setUsers)
    Request('teachers', setTeachers)
    Request('groups', setGroups)
    Request('lessontypes', setTypeLessons)
    Request('classrooms', setClassRooms)
    Request('students', setStudents)
    Request('methodists', setMethodists)
    Request('activities', setActivities)
  }, [])

  

 
  const MyDate = new Date()
  const [datePickerValue, setDatePickerValue] = useState(new Date())
  const [date, setDate] = useState(MyDate.getTime())
  const [UserId, setUserId] = useState(1)

  useEffect(() => {
    setDate(new Date(datePickerValue).getTime())
  }, [datePickerValue]);
  
  const [calendarShow, setCalendarShow] = useState(true)

  

  const cookies = new Cookies();
  const [token, setToken] = useState(cookies.get('token'))

  let options = {
    method: "POST",
    headers: new Headers({
        'Content-Type': 'application/json'
    }),
    body: JSON.stringify({token: token})
  }
  console.log()
  fetch(URL + 'jwt/verify/', options)
  .then(data => {
    if(data.code == '400') {
      setToken('')
    }
    data.json().then(json => {
      if(json.code == 'token_not_valid') {
        setToken('')
      }
    })
  })

  useEffect(() => {
    cookies.set('token', token, { path: '/' });
  }, [token, cookies]);
  // ------------| ADD LESSON |-------------

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // ---------------------------------------

  
  return (
    <>
      <Header token={token}/>

      <main>
        {lessons!= 0 && typeLessons!= 0 &&  groups!= 0 && teachers!= 0 && classRooms!= 0 && users!= 0 && students!= 0  && activities!=0 ? (
          <Navigation 
            lessons={lessons}
            typeLessons={typeLessons} 
            groups={groups} 
            teachers={teachers} 
            classRooms={classRooms}
            setUserId={setUserId}
            date={date}
            UserId={UserId}
            users={users}
            students={students}
            methodists={methodists}
            activities={activities}
            setToken={setToken}
            token={token}
          />
        ): <>Невозможно получить данные с сервера</>}
      </main>
    </>
  )
}

const Request = (name, funk) => {
  let tocken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoiYWNjZXNzIiwiZXhwIjoxNjgwNzg0NjgxLCJqdGkiOiJjYWFiYTc2YjhkYjY0MjQ2YjViYmZiODNmZDE3OGY0MCIsInVzZXJfaWQiOjJ9.rSydiyGy2vvtfDCoH0En0YlzPpPBnDPK2Fa2Y7kIKdg'
  const URLq = 'http://26.81.229.58:8000/api/v1/'

  let options = {
    method: "GET",
    headers: new Headers({
        'Content-Type': 'application/json',
        'X-CSRFToken': tocken
    })
  }
  
  fetch(URLq + name, options)
    .then(data => {
      data.json()
        .then(json => {
          funk(json)
        })
    })

}

const RButton = styled(Button)`
  width: 150px;
  margin-left: auto;
`

const CalendarBox = styled.div`
  position: absolute;
  overflow: hidden;
  width: min-content;
  max-height: ${props => props.calendarShow ? '300px' : '0'};
  height: min-content;
  transition: all 2 linear;
`